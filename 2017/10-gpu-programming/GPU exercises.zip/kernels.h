/*
 * @brief Header of the translation unit containing the GPU kernels.
 *
 *  Created on: 30 nov 2017
 *      Author: lettich
 */


#pragma once


extern __global__ void HillisAndSteele(const int* input, const int size, int* output);


extern __global__ void BlellochSingleBlock(const int* input, const int size, int* output);


extern __global__ void BlellochSingleBlockInclusive(const int* input, const int size, int* output);

// NOTE to the student: Feel free to modify the list of the parameters passed in input to this
// kernel, as you need to use an auxiliary array.
extern __global__ void BlellochMultipleBlocks(const int* input, const int size, int* output);


extern __global__ void BlellochNoConflicts(const int* input, const int size, int* output);
